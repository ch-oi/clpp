package com.example.maptest;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraPosition;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.NaverMapOptions;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.InfoWindow;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.Overlay;
import com.naver.maps.map.util.FusedLocationSource;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1000;
    private FusedLocationSource locationSource;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_map);

        locationSource =
                new FusedLocationSource(this, LOCATION_PERMISSION_REQUEST_CODE);

        CameraPosition cameraPosition = new CameraPosition(
                new LatLng(36.167910, 128.467695), // 대상 지점
                16, // 줌 레벨
                20, // 기울임 각도
                0 // 베어링 각도
        );

        NaverMapOptions options = new NaverMapOptions()
                .camera(cameraPosition)
                .mapType(NaverMap.MapType.Terrain)
                .enabledLayerGroups(NaverMap.LAYER_GROUP_BUILDING)
                .compassEnabled(true)
                .scaleBarEnabled(true)
                .locationButtonEnabled(true);

        FragmentManager fm = getSupportFragmentManager();
        MapFragment mapFragment = (MapFragment) fm.findFragmentById(R.id.fragment_map);
        if (mapFragment == null) {
            mapFragment = MapFragment.newInstance(options);
            fm.beginTransaction().add(R.id.fragment_map, mapFragment).commit();
        }
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (locationSource.onRequestPermissionsResult(
                requestCode, permissions, grantResults)) {
            return;
        }
        super.onRequestPermissionsResult(
                requestCode, permissions, grantResults);
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {
        // 마커1
        Marker marker1 = new Marker();
        marker1.setPosition(new LatLng(36.167840, 128.465839));
        marker1.setMap(naverMap);

        InfoWindow infoWindow1 = new InfoWindow();
        infoWindow1.setAdapter(new InfoWindow.DefaultViewAdapter(this) {
            @NonNull
            @Override
            public View getContentView(@NonNull InfoWindow infoWindow) {
                View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.infowindow_layout, null);
                ImageView imageView = view.findViewById(R.id.imageView);
                TextView textView = view.findViewById(R.id.textView);

                imageView.setImageResource(R.drawable.image1);
                textView.setText("마커1에 대한 정보");

                view.setOnClickListener(v -> {
                    // 정보 창을 클릭했을 때 수행할 작업 추가
                });

                return view;
            }
        });
        infoWindow1.open(marker1);

        // 마커 클릭 시 정보 창 열고 닫기
        Overlay.OnClickListener markerClickListener = overlay -> {
            if (overlay instanceof Marker) {
                Marker clickedMarker = (Marker) overlay;
                InfoWindow associatedInfoWindow = clickedMarker.getInfoWindow();

                if (associatedInfoWindow != null && associatedInfoWindow.getMap() != null) {
                    associatedInfoWindow.close();
                } else {
                    if (clickedMarker.equals(marker1)) {
                        infoWindow1.open(clickedMarker);
                    }
                }
            }

            return true;
        };

        marker1.setOnClickListener(markerClickListener);

        // 마커2
        Marker marker2 = new Marker();
        marker2.setPosition(new LatLng(36.167910, 128.467895));
        marker2.setMap(naverMap);

        InfoWindow infoWindow2 = new InfoWindow();
        infoWindow2.setAdapter(new InfoWindow.DefaultViewAdapter(this) {
            @NonNull
            @Override
            public View getContentView(@NonNull InfoWindow infoWindow) {
                View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.infowindow_layout, null);
                ImageView imageView = view.findViewById(R.id.imageView);
                TextView textView = view.findViewById(R.id.textView);

                imageView.setImageResource(R.drawable.image2);
                textView.setText("마커2에 대한 정보");

                view.setOnClickListener(v -> {
                    // 정보 창을 클릭했을 때 수행할 작업 추가
                });

                return view;
            }
        });
        infoWindow2.open(marker2);

        // 마커 클릭 시 정보 창 열고 닫기
        Overlay.OnClickListener marker2ClickListener = overlay -> {
            if (overlay instanceof Marker) {
                Marker clickedMarker = (Marker) overlay;
                InfoWindow associatedInfoWindow = clickedMarker.getInfoWindow();

                if (associatedInfoWindow != null && associatedInfoWindow.getMap() != null) {
                    associatedInfoWindow.close();
                } else {
                    if (clickedMarker.equals(marker1)) {
                        infoWindow1.open(clickedMarker);
                    } else if (clickedMarker.equals(marker2)) {
                        infoWindow2.open(clickedMarker);
                    }
                }
            }

            return true;
        };

        marker2.setOnClickListener(marker2ClickListener);

        // 마커3
        Marker marker3 = new Marker();
        marker3.setPosition(new LatLng(36.170820, 128.467438));
        marker3.setMap(naverMap);

        InfoWindow infoWindow3 = new InfoWindow();
        infoWindow3.setAdapter(new InfoWindow.DefaultViewAdapter(this) {
            @NonNull
            @Override
            public View getContentView(@NonNull InfoWindow infoWindow) {
                View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.infowindow_layout, null);
                ImageView imageView = view.findViewById(R.id.imageView);
                TextView textView = view.findViewById(R.id.textView);

                imageView.setImageResource(R.drawable.image3);
                textView.setText("마커3에 대한 정보");

                view.setOnClickListener(v -> {
                    // 정보 창을 클릭했을 때 수행할 작업 추가
                });

                return view;
            }
        });
        infoWindow3.open(marker3);

        // 마커 클릭 시 정보 창 열고 닫기
        Overlay.OnClickListener marker3ClickListener = overlay -> {
            if (overlay instanceof Marker) {
                Marker clickedMarker = (Marker) overlay;
                InfoWindow associatedInfoWindow = clickedMarker.getInfoWindow();

                if (associatedInfoWindow != null && associatedInfoWindow.getMap() != null) {
                    associatedInfoWindow.close();
                } else {
                    if (clickedMarker.equals(marker1)) {
                        infoWindow1.open(clickedMarker);
                    } else if (clickedMarker.equals(marker2)) {
                        infoWindow2.open(clickedMarker);
                    } else if (clickedMarker.equals(marker3)) {
                        infoWindow3.open(clickedMarker);
                    }
                }
            }

            return true;
        };

        marker3.setOnClickListener(marker3ClickListener);
    }
}
